import { useState } from 'react';
import Navbar from './components/Navbar.jsx';
import ProductGrid from './components/ProductGrid.jsx';
import SideBar from './components/SideBar.jsx';
import Hero from './components/Hero.jsx';
import Footer from './components/Footer.jsx';
import AdminSidebar from './components/AdminSidebar.jsx';

function App() {
  const [telaAtiva, setTelaAtiva] = useState('loja');
  const [cartItems, setCartItems] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [termoPesquisa, setTermoPesquisa] = useState('');
  const [buscaAdmin, setBuscaAdmin] = useState('');

  const [imputTitle, setImputTitle] = useState('');
  const [imputPrice, setImputPrice] = useState('');
  const [imputImage, setImputImage] = useState('');

  const [imputEstoque, setImputEstoque] = useState('');
  const [imputTamanhos, setImputTamanhos] = useState('');

  const [editandoId, setEditandoId] = useState(null);

  const [products, setProducts] = useState([
    {
      id: 1,
      title: 'Tênis Street Urban',
      price: '599.90',
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500',
      estoque: 12,
      tamanhos: [38, 39, 40, 41],
    },
    {
      id: 2,
      title: 'Bota de Couro Classic',
      price: '549.90',
      image:
        'https://images.unsplash.com/photo-1520639888713-7851133b1ed0?w=500',
      estoque: 5,
      tamanhos: [40, 41, 42],
    },
    {
      id: 3,
      title: 'Sandália Minimal Scarpin',
      price: '419.90',
      image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=500',
      estoque: 8,
      tamanhos: [35, 36, 37],
    },
    {
      id: 4,
      title: 'Sapato Oxford Social',
      price: '899.90',
      image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=500',
      estoque: 3,
      tamanhos: [39, 41, 42, 43],
    },
    {
      id: 5,
      title: 'Tênis Performance Running',
      price: '1199.90',
      image:
        'https://images.unsplash.com/photo-1582588678413-dbf45f4823e9?w=500',
      estoque: 15,
      tamanhos: [38, 39, 40, 41, 42],
    },
    {
      id: 6,
      title: 'Tênis Nova Onda',
      price: '849.90',
      image:
        'https://images.unsplash.com/photo-1539185441755-769473a23570?w=500',
      estoque: 7,
      tamanhos: [37, 38, 39, 40],
    },
    {
      id: 7,
      title: 'Tênis Retro Suede',
      price: '359.90',
      image:
        'https://images.unsplash.com/photo-1607522370275-f14206abe5d3?w=500',
      estoque: 20,
      tamanhos: [39, 40, 41, 42],
    },
    {
      id: 8,
      title: 'Mocassim de Couro',
      price: '249.90',
      image:
        'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=500',
      estoque: 0,
      tamanhos: [38, 39, 40],
    },
  ]);

  function handleAddToCart(produtoClicado) {
    setCartItems([...cartItems, produtoClicado]);
  }

  const handleRemoveFromCart = (id) => {
    const itensNovos = cartItems.filter((item) => item.id !== id);
    setCartItems(itensNovos);
  };

  const produtosFiltrados = products.filter((produto) =>
    produto.title.toLowerCase().includes(termoPesquisa.toLowerCase())
  );

  const excluirProduto = (id) => {
    const confirmar = window.confirm(
      'Deseja prosseguir com a exclusão desse Produto?'
    );
    if (confirmar) {
      const novaLista = products.filter((produto) => produto.id !== id);
      setProducts(novaLista);
      if (editandoId === id) {
        cancelarEdicao();
      }
    }
  };

  function iniciarEdicao(produtoSelecionado) {
    setEditandoId(produtoSelecionado.id);
    setImputTitle(produtoSelecionado.title);
    setImputPrice(produtoSelecionado.price);
    setImputImage(produtoSelecionado.image);
    setImputEstoque(produtoSelecionado.estoque.toString());
    setImputTamanhos(produtoSelecionado.tamanhos.join(', '));
  }

  function cancelarEdicao() {
    setEditandoId(null);
    setImputTitle('');
    setImputPrice('');
    setImputImage('');
    setImputEstoque('');
    setImputTamanhos('');
  }

  function salvarEdicao() {
    if (!imputTitle.trim()) return;

    const arrayTamanhos = imputTamanhos
      .split(',')
      .map((t) => parseInt(t.trim()))
      .filter((t) => !isNaN(t));

    const listaAtualizada = products.map((item) => {
      if (item.id === editandoId) {
        return {
          ...item,
          title: imputTitle.trim(),
          price: imputPrice,
          image: imputImage.trim(),
          estoque: parseInt(imputEstoque) || 0,
          tamanhos: arrayTamanhos,
        };
      }
      return item;
    });

    setProducts(listaAtualizada);
    cancelarEdicao();
  }

  function cadastrar() {
    if (!imputTitle.trim()) return;

    const arrayTamanhos = imputTamanhos
      .split(',')
      .map((t) => parseInt(t.trim()))
      .filter((t) => !isNaN(t));

    const novoItem = {
      id: Date.now(),
      title: imputTitle.trim(),
      price: imputPrice.trim() || '0.00',
      image: imputImage.trim(),
      estoque: parseInt(imputEstoque) || 0,
      tamanhos: arrayTamanhos,
    };

    setProducts([...products, novoItem]);
    cancelarEdicao();
  }

  return (
    <>
      <Navbar
        cartCount={cartItems.length}
        openCart={setIsCartOpen}
        termoPesquisa={termoPesquisa}
        onPesquisa={setTermoPesquisa}
        setTelaAtiva={setTelaAtiva}
      />

      <div className="nav-telas-teste">
        <button onClick={() => setTelaAtiva('loja')}>🛍️ Ver Loja</button>
        <button onClick={() => setTelaAtiva('login')}>👤 Login Cliente</button>
        <button onClick={() => setTelaAtiva('admin')}>⚙️ Painel Admin</button>
      </div>

      {telaAtiva === 'loja' && (
        <>
          <Hero />
          <main className="main-content">
            <h2>Nossos Produtos</h2>
            {produtosFiltrados.length === 0 ? (
              <p
                className="pesquisa-vazia"
                style={{
                  textAlign: 'center',
                  padding: '20px',
                  color: '#6c757d',
                }}
              >
                Nenhum sapato encontrado para "{termoPesquisa}"
              </p>
            ) : (
              <ProductGrid
                onAddCart={handleAddToCart}
                products={produtosFiltrados}
              />
            )}
          </main>
        </>
      )}

      {telaAtiva === 'login' && (
        <main className="main-content pagina-login-container">
          <div className="form login-caixa-formulario">
            <h3>Acesse sua Conta NosPés</h3>
            <input type="email" placeholder="Seu e-mail" />
            <input type="password" placeholder="Sua senha" />
            <button
              className="btn-cadastrar"
              onClick={() => alert('Login simulado!')}
            >
              Entrar
            </button>
            <p className="login-ajuda">
              Esqueceu sua senha? <a href="#recuperar">Clique aqui</a>
            </p>
          </div>

          <div className="login-painel-informacoes">
            <h3>Por que ter uma conta na NosPés?</h3>

            <div className="info-item-cliente">
              <span>🚚</span>
              <div>
                <h4>Rastreamento em Tempo Real</h4>
                <p>
                  Acompanhe a entrega do seu tênis desde a separação no estoque
                  até a sua porta.
                </p>
              </div>
            </div>

            <div className="info-item-cliente">
              <span>🎟️</span>
              <div>
                <h4>Cupons e Descontos Exclusivos</h4>
                <p>
                  Clientes cadastrados recebem ofertas e lançamentos de modelos
                  antes de todo mundo.
                </p>
              </div>
            </div>

            <div className="info-item-cliente">
              <span>🔄</span>
              <div>
                <h4>Troca Fácil e Grátis</h4>
                <p>
                  Não serviu? Você tem até 30 dias para solicitar a primeira
                  troca sem custo nenhum.
                </p>
              </div>
            </div>

            <div className="info-suporte-rodape">
              <p>
                Precisa de ajuda? Fale com a gente:{' '}
                <strong>suporte@nospes.com</strong>
              </p>
            </div>
          </div>
        </main>
      )}

      {telaAtiva === 'admin' && (
        <main className="pagina-admin-total" style={{ padding: '20px' }}>
          <AdminSidebar setTelaAtiva={setTelaAtiva} />
          <h2>Painel de Controle NosPés (Restrito)</h2>

          <div className="form">
            <h3>{editandoId ? 'Editar Produto' : 'Cadastrar produtos'}</h3>
            <input
              type="text"
              placeholder="Nome do Produto"
              value={imputTitle}
              onChange={(e) => setImputTitle(e.target.value)}
            />
            <input
              type="text"
              placeholder="Valor R$"
              value={imputPrice}
              onChange={(e) => setImputPrice(e.target.value)}
            />
            <input
              type="text"
              placeholder="Imagem (URL)"
              value={imputImage}
              onChange={(e) => setImputImage(e.target.value)}
            />

            <input
              type="number"
              placeholder="Qtd em Estoque"
              value={imputEstoque}
              onChange={(e) => setImputEstoque(e.target.value)}
            />
            <input
              type="text"
              placeholder="Tamanhos disponíveis (ex: 38, 39, 40)"
              value={imputTamanhos}
              onChange={(e) => setImputTamanhos(e.target.value)}
            />

            {editandoId ? (
              <div className="form-botoes">
                <button className="btn-cancelar" onClick={cancelarEdicao}>
                  Cancelar
                </button>
                <button className="btn-salvar" onClick={salvarEdicao}>
                  Salvar Alterações
                </button>
              </div>
            ) : (
              <button className="btn-cadastrar" onClick={cadastrar}>
                Cadastrar
              </button>
            )}
          </div>

          <div
            className="painel-administrativo"
            style={{ marginTop: '30px', padding: 0 }}
          >
            <h3>Gerenciar Itens Cadastrados ({products.length})</h3>

            <div className="admin-busca-container">
              <span className="icone-busca">🔍</span>
              <input
                type="text"
                placeholder="Buscar tênis por nome no painel..."
                value={buscaAdmin}
                onChange={(e) => setBuscaAdmin(e.target.value)}
                className="input-busca-admin"
              />
              {buscaAdmin && (
                <button
                  className="btn-limpar-busca"
                  onClick={() => setBuscaAdmin('')}
                >
                  ✕
                </button>
              )}
            </div>

            <div className="lista-admin-container">
              {products
                .filter((prod) =>
                  prod.title.toLowerCase().includes(buscaAdmin.toLowerCase())
                )
                .map((prod) => (
                  <div key={prod.id} className="produto-admin-item">
                    <div className="produto-admin-info">
                      <img src={prod.image} alt={prod.title} />

                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '4px',
                        }}
                      >
                        <span>
                          <strong>{prod.title}</strong> - R$ {prod.price}
                        </span>
                        <span
                          style={{
                            fontSize: '0.85rem',
                            color: prod.estoque === 0 ? '#e03131' : '#6c757d',
                          }}
                        >
                          Estoque:{' '}
                          {prod.estoque === 0
                            ? '❌ ESGOTADO'
                            : `${prod.estoque} un.`}
                        </span>
                        <span style={{ fontSize: '0.85rem', color: '#6c757d' }}>
                          Tamanhos:{' '}
                          {prod.tamanhos.length > 0
                            ? prod.tamanhos.join(', ')
                            : 'Nenhum'}
                        </span>
                      </div>
                    </div>

                    <div className="admin-produto-acoes">
                      <button
                        className="btn-editar"
                        onClick={() => iniciarEdicao(prod)}
                      >
                        ✏️ Editar
                      </button>

                      <button
                        className="btn-excluir"
                        onClick={() => excluirProduto(prod.id)}
                      >
                        🗑️ Excluir
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </main>
      )}

      {isCartOpen && (
        <SideBar
          closeCart={setIsCartOpen}
          cartItems={cartItems}
          onRemover={handleRemoveFromCart}
        />
      )}

      <footer>
        <div
          style={{ cursor: 'pointer' }}
          onClick={() => setTelaAtiva('admin')}
          className="logo-link"
        >
          <img
            src="https://static.nospes.com/logo-v1.svg"
            alt="rodape"
            className="rodape-logo"
          />
        </div>
        Projeto NosPés - Direitos ReSerVadoS hihi
      </footer>
    </>
  );
}

export default App;
