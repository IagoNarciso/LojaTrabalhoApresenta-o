import ProductCard from './ProductCard';

function ProductGrid(props) {
  return (
    <div className="product-grid">
      {props.products.map((product) => (
        <ProductCard
          key={product.id}
          id={product.id}
          title={product.title}
          price={product.price}
          image={product.image}
          onAddCart={props.onAddCart}
        />
      ))}
    </div>
  );
}
export default ProductGrid;
