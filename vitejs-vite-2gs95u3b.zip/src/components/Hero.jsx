export default function Hero() {
  return (
    <section className="hero">
      <h1>Conforto a cada passo</h1>
      <p>Design contemporâneo e durabilidade para o seu dia a dia.</p>
    </section>
  );
}