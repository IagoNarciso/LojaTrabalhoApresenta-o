import { useState } from 'react'; 

function ProductCard({ onAddCart, image, title, price, id }) {

  const [tamanhoSelecionado, setTamanhoSelecionado] = useState('38');

  return (
    <>
      <div className="product-card">
        <img src={image} alt={title} />
        <div className="product-info">
          <h2>{title}</h2>
          <p className="product-price">R${price}</p>
          
          <select 
            className="select-css"
            value={tamanhoSelecionado} 
            onChange={(e) => setTamanhoSelecionado(e.target.value)} 
          > 
            <option value="38">Tamanho 38</option>
            <option value="39">Tamanho 39</option>  
            <option value="40">Tamanho 40</option>  
            <option value="41">Tamanho 41</option>  
            <option value="42">Tamanho 42</option>  
            <option value="43">Tamanho 43</option>
          </select> 

          <button 
            onClick={() => {
              onAddCart({ id, image, title, price, tamanho: tamanhoSelecionado });
            }}
            className="btn-add"
          >
            Adicionar no Carrinho 
          </button>
        </div>
      </div>
    </>
  );
}

export default ProductCard;