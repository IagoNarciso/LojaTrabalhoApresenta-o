import react from 'react'
import './Footer.jsx';

const Footer = () => {
  return (
    <footer className="footer">
     <p>Projeto React - Direitos ReSerVadoS</p>
     </footer>
  );
};

export default Footer;