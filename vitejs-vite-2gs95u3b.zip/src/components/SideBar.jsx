import React, { useState } from 'react';

function SideBar(props) { 
  const [cupomTexto, setCupomTexto] = useState('');
  const [descontoPorcentagem, setDescontoPorcentagem] = useState(0); 
  const [mensagemCupom, setMensagemCupom] = useState({ texto: '', tipo: '' });

  const subtotalCarrinho = props.cartItems.reduce(
    (acumulador, item) => acumulador + Number(item.price), 
    0
  );

  const valorDesconto = subtotalCarrinho * (descontoPorcentagem / 100);
  const totalGeralComDesconto = subtotalCarrinho - valorDesconto;

  const aplicarCupom = () => {
    if (cupomTexto.trim().toUpperCase() === 'NOSPES10') {
      setDescontoPorcentagem(10); 
      setMensagemCupom({ texto: 'Cupom NOSPES10 aplicado! (10% OFF)', tipo: 'sucesso' });
    } else if (cupomTexto.trim() === '') {
      setDescontoPorcentagem(0);
      setMensagemCupom({ texto: '', tipo: '' });
    } else {
      setDescontoPorcentagem(0);
      setMensagemCupom({ texto: 'Cupom inválido ou expirado.', tipo: 'erro' });
    }
  };

  return (
    <div className='cart-overlay'>
      <div className='cart-sidebar'>
        
        <div className='cart-header'>
          <h2>Seu Carrinho</h2>
          <button onClick={() => { props.closeCart(false) }} className='cart-close'>❌</button>
        </div>

        {props.cartItems.length === 0 ? (
          <p className='cart-empty'>Nenhum Item no Carrinho</p>
        ) : (
          <ul className='cart-items-list'>
            {props.cartItems.map((item) => (
              <li key={item.idUnico || item.id} className='item-no-carrinho'>
                
                <div className='item-carrinho-info'>
                  <img 
                    src={item.image} 
                    alt={item.title}                     
                    className='miniatura-carrinho'                   
                  />
                  
                  <div className='item-texto'>
                    <strong>{item.title}</strong>
                    <span className='item-detalhes'> <br></br>
                    <p className="item-tamanho">Tamanho: <strong>{item.tamanho}</strong></p>
                      R$ {Number(item.price).toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                </div>

                <button className="btn-remover" onClick={() => props.onRemover(item.id)}>
                  Remover
                </button>

              </li>
            ))}
          </ul>
        )}

        {props.cartItems.length > 0 && (
          <div className='cart-footer'>
            
            <div className="carrinho-cupom-container" style={{ marginBottom: '15px', width: '100%' }}>
              <label htmlFor="input-cupom" style={{ fontSize: '0.85rem', color: '#495057', fontWeight: '500', display: 'block', marginBottom: '6px' }}>
                Possui cupom de desconto?
              </label>
              <div className="carrinho-cupom-input-group" style={{ display: 'flex', gap: '8px' }}>
                <input
                  id="input-cupom"
                  type="text"
                  placeholder="Ex: NOSPES10"
                  value={cupomTexto}
                  onChange={(e) => setCupomTexto(e.target.value)}
                  style={{ flex: 1, padding: '8px 12px', border: '1px solid #ced4da', borderRadius: '6px' }}
                />
                <button 
                  onClick={aplicarCupom}
                  style={{ backgroundColor: '#495057', color: 'white', border: 'none', padding: '8px 14px', borderRadius: '6px', cursor: 'pointer', fontWeight: '600' }}
                >
                  Aplicar
                </button>
              </div>
              {mensagemCupom.texto && (
                <p className={`cupom-mensagem ${mensagemCupom.tipo}`} style={{ margin: '6px 0 0 0', fontSize: '0.8rem', fontWeight: '600', color: mensagemCupom.tipo === 'sucesso' ? '#2b8a3e' : '#c92a2a' }}>
                  {mensagemCupom.texto}
                </p>
              )}
            </div>

            <div className='cart-total-box' style={{ display: 'flex', flexDirection: 'column', gap: '4px', width: '100%', marginBottom: '10px' }}>
              {descontoPorcentagem > 0 && (
                <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', color: '#6c757d' }}>
                    <span>Subtotal:</span>
                    <span>R$ {subtotalCarrinho.toFixed(2).replace('.', ',')}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', color: '#2b8a3e', fontWeight: '500' }}>
                    <span>Desconto (10%):</span>
                    <span>- R$ {valorDesconto.toFixed(2).replace('.', ',')}</span>
                  </div>
                </>
              )}
              
              <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%', fontSize: '1.1rem', borderTop: descontoPorcentagem > 0 ? '1px dashed #dee2e6' : 'none', paddingTop: descontoPorcentagem > 0 ? '6px' : '0' }}>
                <span>Total:</span>
                <strong>R$ {totalGeralComDesconto.toFixed(2).replace('.', ',')}</strong>
              </div>
            </div>

            <button className='btn-checkout' onClick={() => alert('Compra finalizada com sucesso!')}>
              Finalizar Compra
            </button>
          </div>
        )}

      </div>
    </div>
  );
}

export default SideBar;