import React from 'react';

function Navbar(props) {
  return (
    <nav className="navbar">
      <div className="logo-container">
        <a href="#" className="logo-link">
          <img
            src="https://static.nospes.com/logo-v1.svg"
            alt="Logo"
            className="header-logo"
          />
          <span className="logo-texto">
            Nos<span>Pés</span>
          </span>
        </a>
      </div>

      <div className="search-container">
        <input
          type="text"
          placeholder="Busque por tênis, botas, sapatos..."
          value={props.termoPesquisa}
          onChange={(e) => props.onPesquisa(e.target.value)}
          className="search-input"
        />
        <span className="search-icon">🔍</span>
      </div>

      <br></br>
      <span
        onClick={() => {
          props.openCart(true);
        }}
        className="navbar-cart"
      >
        🛒 Carrinho ({props.cartCount})
      </span>
    </nav>
  );
}
export default Navbar;
