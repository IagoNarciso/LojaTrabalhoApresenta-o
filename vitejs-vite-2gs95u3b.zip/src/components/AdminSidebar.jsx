import React from 'react';

export default function AdminSidebar({ setTelaAtiva }) {
  return ( 
    <aside className="admin-sidebar">
      <div className="admin-sidebar-titulo">NosPés Admin</div>
      <nav className="admin-sidebar-menu">
        <button className="active">👟 Produtos</button>
        <button onClick={() => alert('Função futura!')}>📊 Relatórios</button>
        <button onClick={() => alert('Função futura!')}>🎟️ Cupons</button>
        <button onClick={() => alert('Função futura!')}>⚙️ Configurações</button>
        <button onClick={() => setTelaAtiva('loja')} style={{ marginTop: 'auto', color: '#ff6b6b' }}>
          🚪 Sair do Painel
        </button>
      </nav>
    </aside>
  ); 
}